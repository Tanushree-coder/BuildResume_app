package com.example.buildresume.portfolio;

public interface PortfolioCallback {

    void onPortfolioItemClick(int pos);
}
