package com.example.buildresume.SideNavigation;

public interface ClickedCallback{
    void onSideMenuItemClick(int i);
}
